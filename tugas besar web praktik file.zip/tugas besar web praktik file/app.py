from flask import Flask, render_template, session, request, redirect, url_for, flash
from flask_mysqldb import MySQL


 
app = Flask(__name__)
app.secret_key = "!@#$%"
  

   
# MySQL configurations
app.config['MYSQL_HOST']='localhost'
app.config['MYSQL_USER']='root'
app.config['MYSQL_PASSWORD']=''
app.config['MYSQL_DB']='perpustakaan'
mysql = MySQL(app)
 
@app.route('/', methods=['GET','POST'])
def login():
    #cek jika methods POST dan ada form data maka proses login
    if request.method == 'POST' and 'inpEmail' in request.form and 'inpPass' in request.form :
        #buat variabel untuk memudahkan pengolahan data
        email = request.form['inpEmail']
        passwd = request.form['inpPass']
        #cursor koneksi mysql
        cur = mysql.connection.cursor()
        #eksekusi kueri
        cur.execute("SELECT * FROM admin where email = %s and password= %s", (email, passwd))
        #fetch hasil
        result = cur.fetchone()
        #cek hasil kueri
        if result:
            session['is_logged_in'] = True
            return redirect(url_for('Buku'))
        else:
            return render_template('login.html')
    else:
        return render_template('login.html')
    
@app.route('/register', methods=['GET', 'POST'])
def register():
    # Jika metode adalah GET, tampilkan formulir registrasi
    if request.method == 'GET':
        return render_template('register.html')
    # Jika metode adalah POST, proses data registrasi yang diterima
    else:
        nama = request.form['nama']
        email = request.form['email']
        password = request.form['password'].encode('utf-8')

        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO admin (nama, email, password) VALUES (%s, %s, %s)", (nama, email, password)) 
        mysql.connection.commit()
        # Redirect ke halaman home setelah registrasi berhasil
        return redirect(url_for('login'))

@app.route('/buku')
def Buku():
    if 'is_logged_in' in session:
        cur = mysql.connection.cursor()
    
        cur.execute('SELECT * FROM buku')
        data = cur.fetchall()
        cur.close()
        return render_template('index_buku.html', buku = data)
    else:
        return redirect(url_for('login'))

@app.route('/anggota')
def Anggota():
    cur = mysql.connection.cursor()
    
    cur.execute('SELECT * FROM anggota')
    data = cur.fetchall()
    cur.close()
    return render_template('index_anggota.html', anggota = data)

@app.route('/peminjaman')
def Peminjaman():
    cur = mysql.connection.cursor()
    
    cur.execute('SELECT * FROM peminjaman')
    data = cur.fetchall()

    cur.execute('SELECT * FROM buku')
    opt = cur.fetchall()

    cur.execute('SELECT * FROM anggota')
    item = cur.fetchall()
    cur.close()
    return render_template('index_peminjaman.html', peminjaman = data, buku=opt, anggota=item)
 
@app.route('/add_buku', methods=['POST'])
def add_buku():
    cur = mysql.connection.cursor()
    if request.method == 'POST':
        judul = request.form['judul']
        kategori = request.form['kategori']
        genre = request.form['genre']
        author = request.form['author']
        penerbit = request.form['penerbit']
        status = request.form['status']
        cur.execute("INSERT INTO buku (judul, kategori, genre, author, penerbit, status) VALUES (%s,%s,%s,%s,%s,%s)", (judul, kategori, genre, author, penerbit, status))
        mysql.connection.commit()
        flash('Buku Berhasil Ditambahkan')
        return redirect(url_for('Buku'))

@app.route('/add_anggota', methods=['POST'])
def add_anggota():
    cur = mysql.connection.cursor()
    if request.method == 'POST':
        npm = request.form['npm']
        nama = request.form['nama']
        prodi = request.form['prodi']
        telepon = request.form['telepon']
        cur.execute("INSERT INTO anggota (npm, nama, prodi, telepon) VALUES (%s,%s,%s,%s)", (npm, nama, prodi, telepon))
        mysql.connection.commit()
        flash('Anggota Berhasil Ditambahkan')
        return redirect(url_for('Anggota'))

@app.route('/add_peminjaman', methods=['POST'])
def add_peminjaman():
    cur = mysql.connection.cursor()
    if request.method == 'POST':
        id_buku = request.form['id_buku']
        id_anggota = request.form['id_anggota']
        pengembalian = request.form['pengembalian']
        cur.execute("INSERT INTO peminjaman (id_buku, id_anggota, tanggal_pengembalian) VALUES (%s,%s,%s)", (id_buku, id_anggota, pengembalian))
        mysql.connection.commit()
        flash('Peminjaman Berhasil Dilakukan')
        return redirect(url_for('Peminjaman'))
    
@app.route('/edit_buku/<id>', methods = ['POST', 'GET'])
def get_buku(id):
    cur = mysql.connection.cursor()
   
    cur.execute('SELECT * FROM buku WHERE id_buku = %s', (id,))
    data = cur.fetchall()
    cur.close()
    print(data[0])
    return render_template('edit_buku.html', data = data[0])
    
@app.route('/update_buku/<id>', methods=['POST'])
def update_buku(id):
    if request.method == 'POST':
        judul = request.form['judul']
        kategori = request.form['kategori']
        genre = request.form['genre']
        author = request.form['author']
        penerbit = request.form['penerbit']
        status = request.form['status']
        cur = mysql.connection.cursor()
        cur.execute("""
            UPDATE buku
            SET judul = %s,
                kategori = %s,
                genre = %s,
                author = %s,
                penerbit = %s,
                status = %s
            WHERE id_buku = %s
        """, (judul, kategori, genre, author, penerbit, status, id))
        flash('Buku Berhasil diupdate')
        mysql.connection.commit()
        return redirect(url_for('Buku'))
    
@app.route('/edit_anggota/<id>', methods = ['POST', 'GET'])
def get_anggota(id):
    cur = mysql.connection.cursor()
   
    cur.execute('SELECT * FROM anggota WHERE id_anggota = %s', (id,))
    data = cur.fetchall()
    cur.close()
    print(data[0])
    return render_template('edit_anggota.html', data = data[0])
    
@app.route('/update_anggota/<id>', methods=['POST'])
def update_anggota(id):
    if request.method == 'POST':
        npm = request.form['npm']
        nama = request.form['nama']
        prodi = request.form['prodi']
        telepon = request.form['telepon']
        cur = mysql.connection.cursor()
        cur.execute("""
            UPDATE anggota
            SET npm = %s,
                nama = %s,
                prodi = %s,
                telepon = %s
            WHERE id_anggota = %s
        """, (npm, nama, prodi, telepon, id))
        flash('Anggota Berhasil diupdate')
        mysql.connection.commit()
        return redirect(url_for('Anggota'))
 
@app.route('/delete_buku/<id>', methods = ['GET'])
def delete_buku(id):
    
    cur = mysql.connection.cursor()
  
    cur.execute('DELETE FROM buku WHERE id_buku = %s',(id,))
    mysql.connection.commit()
    flash('Buku Berhasil Dihapus')
    return redirect(url_for('Buku'))

@app.route('/delete_anggota/<id>', methods = ['GET'])
def delete_anggota(id):
    
    cur = mysql.connection.cursor()
  
    cur.execute('DELETE FROM anggota WHERE id_anggota = %s',(id,))
    mysql.connection.commit()
    flash('Anggota Berhasil Dihapus')
    return redirect(url_for('Anggota'))

@app.route('/delete_peminjaman/<id>', methods = ['GET'])
def delete_peminjaman(id):
    
    cur = mysql.connection.cursor()
  
    cur.execute('DELETE FROM peminjaman WHERE id_peminjaman = %s',(id,))
    mysql.connection.commit()
    flash(' Buku Berhasil Dikembalikan ')
    return redirect(url_for('Peminjaman'))

@app.route('/logout')
def logout():
    session.pop('is_logged_in', None)
    session.pop('username', None)
    return redirect(url_for('login'))
 
# starting the app
if __name__ == "__main__":
    app.run(port=3000, debug=True)
