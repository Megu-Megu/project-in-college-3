from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL

app = Flask(__name__)
app.secret_key = 'your_secret_key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'rentalgame'

mysql = MySQL(app)

# Fungsi untuk validasi login
def login_user(username, password):
    cursor = mysql.connection.cursor()
    cursor.execute("SELECT * FROM data_peminjaman WHERE username = %s", (username,))
    user = cursor.fetchone()
    cursor.close()

    if user and user[1] == password:
        return user
    return None

# Fungsi untuk logout
def logout_user():
    session.clear()

# Route untuk halaman login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Cek apakah username dan password sesuai
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM data_peminjaman WHERE username = %s AND password = %s", (username, password))
        user = cur.fetchone()
        cur.close()

        if user:
            # Jika sesuai, set session dan redirect ke halaman utama
            session['username'] = username
            return redirect(url_for('home'))
        else:
            # Jika tidak sesuai, tampilkan pesan kesalahan
            error = 'Login failed. Please check your username and password.'
            return render_template('login.html', error=error)

    return render_template('login.html')

# Route untuk halaman utama setelah login
@app.route('/')
def home():
    # Cek apakah pengguna sudah login
    if 'username' in session:
        username = session['username']
        # Ambil data pengguna dari database
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM data_peminjaman WHERE username = %s", (username,))
        user = cur.fetchone()
        cur.close()
        return render_template('home.html', user=user)
    else:
        return redirect(url_for('login'))
        
# Route untuk logout
@app.route('/logout')
def logout():
    # Hapus session dan redirect ke halaman login
    session.pop('username', None)
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)

    